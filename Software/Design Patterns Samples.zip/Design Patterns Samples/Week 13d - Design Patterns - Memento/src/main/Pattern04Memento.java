package main;

import domain.ShoppingCart;
import domain.ShoppingItem;

public class Pattern04Memento {

	public static void main(String[] args) {
		ShoppingCart cart = new ShoppingCart("Khalid");
		cart.add(new ShoppingItem("Bread", 1.99d));
		System.out.println(cart);
		cart.add(new ShoppingItem("Milk", 1.89d));
		cart.add(new ShoppingItem("Apple", 0.89d));
		cart.add(new ShoppingItem("Apple", 0.89d));
		System.out.println(cart);
		cart.rollback();
		System.out.println(cart);
		cart.add(new ShoppingItem("Firecrackers", 8.89d));
		cart.add(new ShoppingItem("Hengrenade", 0.89d));
		cart.add(new ShoppingItem("Hengrenade", 0.89d));
		cart.add(new ShoppingItem("Hengrenade", 0.89d));
		System.out.println(cart);
		cart.rollback();
		cart.rollback();
		System.out.println(cart);
	}
}
