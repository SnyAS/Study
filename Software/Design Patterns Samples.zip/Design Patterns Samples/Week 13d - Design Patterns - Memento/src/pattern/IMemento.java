package pattern;

public interface IMemento<T> {
	void store();
	T rollback();
}
