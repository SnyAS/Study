package domain;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import pattern.IMemento;

public class ShoppingCart implements Cloneable {
	private String shopper;
	private List<ShoppingItem> items;
	private ShoppingCartHistory history;

	public ShoppingCart(String shopper) {
		super();
		this.shopper = shopper;
		items = new ArrayList<ShoppingItem>();
		history = new ShoppingCartHistory(this);
	}
	
	public String getShopper() {
		return shopper;
	}

	public ShoppingItem getItem(int index) {
		return items.get(index);
	}
	
	public void add(ShoppingItem item) {
		history.store();
		items.add(item);
	}
	
	public void remove(ShoppingItem item) {
		history.store();
		items.remove(item);
	}
	
	public void remove(int index) {
		history.store();
		items.remove(index);
	}
	
	public int size() {
		return items.size();
	}
	
	public void rollback() {
		ShoppingCart temp = history.rollback();
		this.shopper = temp.shopper;
		this.items = temp.items;
	}
	
	@Override
	public String toString() {
		StringBuilder temp = new StringBuilder("Cart of " + shopper + "\n");
		for (ShoppingItem item: items) {
			temp.append(item);
			temp.append("\n");
		}
		return new String(temp);
	}
	
	@Override
	public ShoppingCart clone() {
		ShoppingCart temp = new ShoppingCart(this.shopper);
		for (ShoppingItem item: items) {
			ShoppingItem newItem = item.clone();
			temp.add(newItem);
		}
		return temp;
	}
	
	class ShoppingCartHistory implements IMemento<ShoppingCart> {
		private LinkedList<ShoppingCart> history;
		private ShoppingCart cart;

		public ShoppingCartHistory(ShoppingCart cart) {
			this.cart = cart;
			history = new LinkedList<ShoppingCart>();
		}
		
		@Override
		public void store() {
			history.add(cart.clone());
		}
		
		@Override
		public ShoppingCart rollback() {
			return history.removeLast();
		}
	}
}
