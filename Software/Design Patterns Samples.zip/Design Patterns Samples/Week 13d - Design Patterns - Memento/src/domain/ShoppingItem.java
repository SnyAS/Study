package domain;

public class ShoppingItem implements Cloneable {
	private String name;
	private String description;
	private double price;

	public ShoppingItem(String name, String description, double price) {
		super();
		this.name = name;
		this.description = description;
		this.price = price;
	}
	
	public ShoppingItem(String name, double price) {
		this(name, null, price);
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "ShoppingItem: " + name + ", price=" + price;
	}
	
	@Override
	public ShoppingItem clone() {
		return new ShoppingItem(name, description, price);
	}
}
