package domain;

import pattern.IStrategy;

public class GamblingAddict {
	private String name;
	private String winningLotteryNumber = null;
	
	public GamblingAddict(String name) {
		this.name = name;
	}

	public void setWinningNumber(IStrategy strategy) {
		winningLotteryNumber = strategy.giveLotteryNumber();
	}
	
	@Override
	public String toString() {
		return name + " takes lottery number: " + winningLotteryNumber;
	}
}
