package domain;

import pattern.IStrategy;

public class SimpleLotteryNumberStrategy implements IStrategy {

	@Override
	public String giveLotteryNumber() {
		String result = "";
		for (int i=0; i<5; i++) {
			String temp = String.valueOf((int)(Math.random() * 99)+1);
			if (temp.length() == 1) {
				temp = "0" + temp;
			}
			result = result + temp + ".";
		}
		result = result + String.valueOf((int)(Math.random() * 99)+1);
		return result;
	}
}
