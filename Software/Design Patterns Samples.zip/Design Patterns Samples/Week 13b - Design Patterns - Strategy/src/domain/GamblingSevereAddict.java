package domain;

import pattern.IStrategy;

public class GamblingSevereAddict {
	private String name;
	private IStrategy strategy = null;
	
	public GamblingSevereAddict(String name, IStrategy strategy) {
		this.name = name;
		this.strategy = strategy;
	}
	
	@Override
	public String toString() {
		return name + " takes lottery number: " + strategy.giveLotteryNumber();
	}
}
