package domain;

import java.util.Date;

import pattern.IStrategy;

public class DateLotteryNumberStrategy implements IStrategy {

	@Override
	public String giveLotteryNumber() {
		String result = "";
		String temp = String.valueOf(new Date().getTime());
		for (int i=0; i<5; i++) {
			result = result + temp.substring(i*2, i*2+2) + ".";
		}
		result = result + temp.substring(10, 12);
		return result;
	}
}
