package main;

import domain.DateLotteryNumberStrategy;
import domain.GamblingAddict;

public class Pattern02Strategy2 {

	public static void main(String[] args) {
		new Pattern02Strategy2();
	}

	public Pattern02Strategy2() {
		GamblingAddict harry = new GamblingAddict("Harry");
		harry.setWinningNumber(new DateLotteryNumberStrategy());
		System.out.println(harry);
	}
}
