package main;

import domain.GamblingAddict;
import domain.SimpleLotteryNumberStrategy;

public class Pattern02Strategy {

	public static void main(String[] args) {
		new Pattern02Strategy();
	}

	public Pattern02Strategy() {
		GamblingAddict harry = new GamblingAddict("Harry");
		harry.setWinningNumber(new SimpleLotteryNumberStrategy());
		System.out.println(harry);
	}
}
