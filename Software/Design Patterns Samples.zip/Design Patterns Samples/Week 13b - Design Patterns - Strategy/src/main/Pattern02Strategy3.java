package main;

import domain.DateLotteryNumberStrategy;
import domain.GamblingAddict;
import domain.GamblingSevereAddict;
import domain.SimpleLotteryNumberStrategy;

public class Pattern02Strategy3 {

	public static void main(String[] args) throws InterruptedException {
		new Pattern02Strategy3();
	}

	public Pattern02Strategy3() throws InterruptedException {
		GamblingSevereAddict jane = new GamblingSevereAddict("Jane", new DateLotteryNumberStrategy());
		GamblingAddict harry = new GamblingAddict("Harry");
		for (int i=0; i<5; i++) {
			harry.setWinningNumber(new SimpleLotteryNumberStrategy());
			System.out.println(harry);
			System.out.println(jane);
			Thread.sleep(1000);
		}
	}
}
