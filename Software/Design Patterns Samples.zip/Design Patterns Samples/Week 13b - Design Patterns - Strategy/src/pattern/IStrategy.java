package pattern;

public interface IStrategy {
	String giveLotteryNumber();

}
