package main;

import java.util.ArrayList;
import java.util.List;

import domain.Airplane;
import domain.Muncipality;
import domain.Person;

public class Pattern01Observer2 {

	public static void main(String[] args) {
		new Pattern01Observer2();
	}

	Pattern01Observer2() {
		// Set up a List of Persons. Can be solved neater, but for a PoC, this will suffice
		List<Person> persons = new ArrayList<Person>(1000);
		// Create a new Muncipality
		Muncipality town = new Muncipality("Utopia");
		
		// Create a bunch of persons and add them to the town
		for (int i=0; i<1000; i++) {
			Person inhabitant = new Person("Person " + Integer.valueOf(i), "Address " + Integer.valueOf(i));
			persons.add(inhabitant);
			town.addInhabitant(inhabitant);
		}
		
		// Now also add an Airplane to the town (very rich mayor?)
		Airplane plane = new Airplane("Utopia 001", 0); // Starts on the ground
		town.addInhabitant(plane);
		
		// Test the observing pattern by moving some inhabitants
		persons.get(5).setAddress("Prison 44");
		persons.get(100).setAddress("Somewhere abroad");
		persons.get(222).setAddress(persons.get(277).getAddress()); // Moved in with another
		
		// And the plane takes off
		plane.setAltitude(30000);
	}
}
