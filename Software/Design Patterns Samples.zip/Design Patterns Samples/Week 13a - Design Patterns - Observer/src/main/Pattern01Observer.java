package main;

import java.util.ArrayList;
import java.util.List;

import domain.Muncipality;
import domain.Person;

public class Pattern01Observer {

	public static void main(String[] args) {
		new Pattern01Observer();
	}

	Pattern01Observer() {
		// Set up a List of Persons. Can be solved neater, but for a PoC, this will suffice
		List<Person> persons = new ArrayList<Person>(1000);
		// Create a new Muncipality
		Muncipality town = new Muncipality("Utopia");
		
		// Create a bunch of persons and add them to the town
		for (int i=0; i<1000; i++) {
			Person inhabitant = new Person("Person " + Integer.valueOf(i), "Address " + Integer.valueOf(i));
			persons.add(inhabitant);
			town.addInhabitant(inhabitant);
		}
		
		// Test the observing pattern by moving some inhabitants
		persons.get(5).setAddress("Prison 44");
		persons.get(100).setAddress("Somewhere abroad");
		persons.get(222).setAddress(persons.get(277).getAddress()); // Moved in with another
	}
}
