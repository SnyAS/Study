package main;

import java.util.ArrayList;
import java.util.List;

import domain.LittleGreyMan;
import domain.Person;

public class Pattern01Observer3 {

	public static void main(String[] args) {
		new Pattern01Observer3();
	}

	Pattern01Observer3() {
		// Set up a List of Persons. Can be solved neater, but for a PoC, this will suffice
		List<Person> subjects = new ArrayList<Person>(50);
		// Create a new little grey man
		LittleGreyMan ufo = new LittleGreyMan();
		
		// Create a bunch of persons and add them to the ufo
		for (int i=0; i<20; i++) {
			Person subject = new Person("Subject " + Integer.valueOf(i), "Address " + Integer.valueOf(i));
			subjects.add(subject);
			ufo.addSubject(subject);
		}
		
		// Test the observing pattern by moving some inhabitants
		subjects.get(5).setAddress("Prison 44");
		subjects.get(12).setAddress("Somewhere abroad");
	}
}
