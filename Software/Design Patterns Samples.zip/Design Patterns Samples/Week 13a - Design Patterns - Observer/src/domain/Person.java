package domain;

import java.util.ArrayList;
import java.util.Collection;

import pattern.IObservable;
import pattern.IObserver;

public class Person implements IObservable {
	private String address; // Not a very good choice, as it should be a class itself. But for PoC purposes it will suffice
	private final String name;
	private Collection<IObserver> observers;  // To store the observers
	
	public Person(String name, String address) {
		super();
		this.name = name;
		this.address = address;
		observers = new ArrayList<IObserver>(); // Could be a Set as well!
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
		this.notifyObservers();
	}

	@Override
	public boolean attach(IObserver observer) {
		return observers.add(observer); // Allows duplicate observers; to be solved after the Collections framework
		
	}

	@Override
	public boolean detach(IObserver observer) {
		return observers.remove(observer);
	}

	@Override
	public void notifyObserver(IObserver observer) {
		observer.update(this); // Would actually allow for notifying a non-attached observer. To be solved later
		
	}

	@Override
	public void notifyObservers() {
		// Better would be to check whether the Observable has indeed changed before running the loop
		// To be solved later
		for (IObserver observer: observers) {
			this.notifyObserver(observer);
		}
	}
	
	public String toString() {
		return this.getName();
	}
	
	public String getStatus() {
		return this.getAddress();
	}
}
