package domain;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import pattern.IObservable;
import pattern.IObserver;

public class LittleGreyMan implements IObserver {
	private List<IObservable> testSubjects;

	public LittleGreyMan() {
		testSubjects = new ArrayList<IObservable>(20);
	}

	public boolean addSubject(IObservable observable) {
		observable.attach(this);
		return testSubjects.add(observable);
	}
	
	public boolean removeSubject(IObservable observable) {
		observable.detach(this);
		return testSubjects.remove(observable);
	}
	
	@Override
	public void update(IObservable source) {
		try {
			Method getStatus = source.getClass().getMethod("getStatus", (Class<?>[])null);
			System.out.println("Test subject " + source + " changed. New status is: " + getStatus.invoke(source) + ". Updating files.");
		} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			e.printStackTrace();
		}
	}
}
