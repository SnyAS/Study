package domain;

import java.util.Collection;
import java.util.HashSet;

import pattern.IObservable;
import pattern.IObserver;

public class Airplane implements IObservable {
	private String name;
	private int altitude;
	private Collection<IObserver> observers;  // To store the observers

	public Airplane(String name, int altitude) {
		super();
		this.name = name;
		this.altitude = altitude;
		observers = new HashSet<IObserver>(); 
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
		this.notifyObservers();
	}

	public int getAltitude() {
		return altitude;
	}

	public void setAltitude(int altitude) {
		this.altitude = altitude;
		this.notifyObservers();
	}

	@Override
	public boolean attach(IObserver observer) {
		return observers.add(observer);
		
	}

	@Override
	public boolean detach(IObserver observer) {
		return observers.remove(observer);
	}

	@Override
	public void notifyObserver(IObserver observer) {
		observer.update(this); // Would actually allow for notifying a non-attached observer. To be solved later
	}

	@Override
	public void notifyObservers() {
		// Better would be to check whether the Observable has indeed changed before running the loop
		// To be solved later
		for (IObserver observer: observers) {
			this.notifyObserver(observer);
		}
	}
	
	public String toString() {
		return this.getName();
	}
	
	public String getStatus() {
		return "Altitude: " + String.valueOf(this.getAltitude());
	}
}