package domain;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import pattern.IObservable;
import pattern.IObserver;

public class Muncipality implements IObserver {
	private List<IObservable> inhabitants;
	private String name;

	public Muncipality(String name) {
		super();
		this.name = name;
		inhabitants = new ArrayList<IObservable>(5000); // We expect a certain size of the town
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean addInhabitant(IObservable observable) {
		observable.attach(this);
		return inhabitants.add(observable);
	}
	
	public boolean removeInhabitant(IObservable observable) {
		observable.detach(this);
		return inhabitants.remove(observable);
	}
	
	@Override
	public void update(IObservable source) {
		// When a person moves, we print the action to take to the console
		// Careful now; the who does not have to be a person anymore!
		// Doing some nasty Reflection just because it's fun
		try {
			Method getStatus = source.getClass().getMethod("getStatus", (Class<?>[])null);
			System.out.println("Inhabitant " + source + " changed. New status is: " + getStatus.invoke(source) + ". Updating files.");
		} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			e.printStackTrace();
		}
	}
}
