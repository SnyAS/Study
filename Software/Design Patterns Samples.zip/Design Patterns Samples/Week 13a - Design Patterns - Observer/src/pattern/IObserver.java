package pattern;

public interface IObserver {
	void update(IObservable source);

}
