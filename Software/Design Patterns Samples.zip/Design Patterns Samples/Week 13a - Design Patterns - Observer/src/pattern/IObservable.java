package pattern;
public interface IObservable {
	boolean attach(IObserver observer);
	boolean detach(IObserver observer);
	void notifyObserver(IObserver observer); // Cannot use notify because Object already defines it as final
	void notifyObservers(); // Same here
}
