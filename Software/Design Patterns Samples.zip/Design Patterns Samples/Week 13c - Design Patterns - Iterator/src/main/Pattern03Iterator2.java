package main;

import domain.Burger;
import domain.MacDonalds;
import pattern.IIterator;

public class Pattern03Iterator2 {

	public static void main(String[] args) {
		MacDonalds restaurant = new MacDonalds();
		IIterator<Burger> iterator = restaurant.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		System.out.println("");
		
		iterator = restaurant.iterator();
		IIterator<Burger> otherIterator = restaurant.iterator();
		while (iterator.hasNext()) {
			Burger burger = iterator.next();
			if (burger.getName().equals("Plain")) {
				iterator.delete();
				if (otherIterator.hasNext()) {
					otherIterator.next();
					if (Math.random() < 0.7) {
						otherIterator.delete();
					}
				}
			}
		}
		System.out.println(restaurant);
		System.out.println("");
	}
}
