package main;

import domain.Burger;
import domain.MacDonalds;
import pattern.IIterator;

public class Pattern03Iterator {

	public static void main(String[] args) {
		MacDonalds restaurant = new MacDonalds();
		IIterator<Burger> iterator = restaurant.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		System.out.println("");
		
		iterator = restaurant.iterator();
		while (iterator.hasNext()) {
			Burger burger = iterator.next();
			if (burger.getName().equals("Plain")) {
				iterator.delete();
			}
		}
		System.out.println(restaurant);
		System.out.println("");
	}
}
