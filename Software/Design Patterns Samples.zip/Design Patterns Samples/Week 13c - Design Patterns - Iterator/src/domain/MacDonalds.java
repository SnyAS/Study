package domain;

import java.util.Arrays;

import pattern.IIterable;
import pattern.IIterator;

public class MacDonalds implements IIterable<MacDonalds> {
	private Burger[] menu;
	
	public MacDonalds() {
		menu = new Burger[30];
		for (int i=0; i<28; i+=3) {
			menu[i] = new Burger("Cheese", 4.99d);
			menu[i+1] = new Burger("Plain", 1.99d);
			menu[i+2] = new Burger("Whopper", 5.99d);
		}
	}

	@Override
	public IIterator<Burger> iterator() {
		return new MacDonaldsIterator();
	}
	
	@Override
	public String toString() {
		StringBuilder temp = new StringBuilder();
		temp.append("Menu of this MacDonalds\n");
		for (Burger burger: menu) {
			temp.append(burger);
			temp.append("\n");
		}
		return new String(temp);
	}
	
	class MacDonaldsIterator implements IIterator<Burger> {
		private int index = -1;

		@Override
		public Burger next() {
			index++;
			return menu[index];
		}

		@Override
		public boolean hasNext() {
			if (index < menu.length-1) {
				return true;
			}
			else {
				return false;
			}
		}

		@Override
		public void delete() {
			for (int i=index; i<menu.length-1; i++) {
				menu[i] = menu[i+1];
			}
			Burger[] temp = Arrays.copyOf(menu, menu.length-1);
			menu = temp;
			index--;
		}
	}
}
