package pattern;

public interface IIterator<Burger> {
	Burger next();
	boolean hasNext();
	void delete();
}
