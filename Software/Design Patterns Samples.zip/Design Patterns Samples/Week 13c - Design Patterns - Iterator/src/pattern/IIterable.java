package pattern;

import domain.Burger;

public interface IIterable<MacDonalds> {
	IIterator<Burger> iterator();
}
