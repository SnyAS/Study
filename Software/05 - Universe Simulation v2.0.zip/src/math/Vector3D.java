package math;

import static util.Constants.ROUND;

import java.math.BigDecimal;

import util.BigDecimalMath;

public class Vector3D {
	private BigDecimal x;
	private BigDecimal y;
	private BigDecimal z;
	
	public Vector3D(BigDecimal x, BigDecimal y, BigDecimal z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}
	
	public BigDecimal getX() {
		return x;
	}

	public BigDecimal getY() {
		return y;
	}
	
	public void setX(BigDecimal x) {
		this.x = x;
	}

	public void setY(BigDecimal y) {
		this.y = y;
	}

	public BigDecimal getZ() {
		return z;
	}

	public void setZ(BigDecimal z) {
		this.z = z;
	}

	public Vector3D times(BigDecimal n){
		return new Vector3D(x.multiply(n),y.multiply(n), z.multiply(n));
	}
	
	public Vector3D divide(BigDecimal n){
		return new Vector3D(x.divide(n,50,ROUND),y.divide(n,50,ROUND),z.divide(n,50,ROUND));
	}
	
	public Vector3D minus(Vector3D other){
		return new Vector3D(x.add((other.getX()).negate()),y.add((other.getY()).negate()),z.add((other.getZ()).negate()));
	}
	
	public Vector3D add(Vector3D other) {
		return new Vector3D(x.add(other.getX()),y.add(other.getY()), z.add(other.getZ()));
	}
	
	public BigDecimal getLength() {
		return BigDecimalMath.sqrt((x.multiply(x)).add(y.multiply(y)).add(z.multiply(z)));
	}
	
	
	public BigDecimal getDistance(Vector3D other){
		BigDecimal dx = x.add(other.getX().negate());
		BigDecimal dy = y.add(other.getY().negate());
		BigDecimal dz = z.add(other.getZ().negate());
		return BigDecimalMath.sqrt((dx.multiply(dx)).add(dy.multiply(dy)).add(dz.multiply(dz)));
	}


	@Override
	public String toString() {
		return "Vector [x=" + x + ", y=" + y + ", z=" + z + ", length=" + getDistance(new Vector3D(BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO)) + "]";
	}
}
