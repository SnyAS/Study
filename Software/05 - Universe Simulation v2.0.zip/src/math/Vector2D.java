package math;

import static util.Constants.ROUND;

import java.math.BigDecimal;

import util.BigDecimalMath;

public class Vector2D {
	private volatile BigDecimal x;
	private volatile BigDecimal y;
	
	public Vector2D(BigDecimal x, BigDecimal y) {
		this.x = x;
		this.y = y;
	}
	
	public BigDecimal getX() {
		return x;
	}

	public BigDecimal getY() {
		return y;
	}
	
	public void setX(BigDecimal x) {
		this.x = x;
	}

	public void setY(BigDecimal y) {
		this.y = y;
	}

	public Vector2D times(BigDecimal n){
		return new Vector2D(x.multiply(n),y.multiply(n));
	}
	
	public Vector2D divide(BigDecimal n){
		return new Vector2D(x.divide(n,50,ROUND),y.divide(n,50,ROUND));
	}
	
	public Vector2D minus(Vector2D other){
		return new Vector2D(x.add((other.getX()).negate()),y.add((other.getY()).negate()));
	}
	
	public Vector2D add(Vector2D other) {
		return new Vector2D(x.add(other.getX()),y.add(other.getY()));
	}
	
	public BigDecimal getLength() {
		return BigDecimalMath.sqrt((x.multiply(x)).add(y.multiply(y)));
	}
	
	
	public BigDecimal getDistance(Vector2D other){
		BigDecimal dx = x.add(other.getX().negate());
		BigDecimal dy = y.add(other.getY().negate());
		return BigDecimalMath.sqrt((dx.multiply(dx)).add(dy.multiply(dy)));
	}


	@Override
	public String toString() {
		return "Vector [x=" + x + ", y=" + y + ", z=" + ", length=" + getDistance(new Vector2D(BigDecimal.ZERO, BigDecimal.ZERO)) + "]";
	}
}
