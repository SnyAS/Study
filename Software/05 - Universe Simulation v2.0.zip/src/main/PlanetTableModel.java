package main;

import static util.Constants.INTERVAL;

import java.math.MathContext;

import javax.swing.table.AbstractTableModel;

public class PlanetTableModel extends AbstractTableModel {
	private static final long serialVersionUID = 1L;
	private final Object columnNames[] = { "Planet" , "Speed (km / sec)", "X (m)", "Y (m)" };
	private final UniverseController controller;
	
	public PlanetTableModel(UniverseController controller) {
		super();
		this.controller = controller;
	}

	@Override
	public int getColumnCount() {
		return 4;
	}

	@Override
	public int getRowCount() {
		return controller.getBodies().size();
	}

	@Override
	public Object getValueAt(int row, int column) {
		switch(column) {
			case 0: return controller.getBodies().get(row).getName();
			case 1: return ((float)(controller.getBodies().get(row).getVelocity().getLength().intValue() / INTERVAL))/1000;
			case 2: return controller.getBodies().get(row).getLocation().getX().round(new MathContext(11));
			case 3: return controller.getBodies().get(row).getLocation().getY().round(new MathContext(11));
			default: return null;
		}
	}

	@Override
	public String getColumnName(int column) {
		return columnNames[column].toString();
	}
}