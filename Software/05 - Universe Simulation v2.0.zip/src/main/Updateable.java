package main;

public interface Updateable {
	void update();

}
