package main;

import java.math.BigDecimal;
import java.util.ArrayList;

import physics.Body;
import physics.Universe;

import static util.Constants.UPDATE_FREQUENCY;
import static util.Constants.INTERVAL;

public class UniverseController {
	private Thread innerThread;
	private Universe universe;
	private BigDecimal maxRadius;
	private Updateable view;
	private volatile long numberOfStepsTaken = 0;
	
	public UniverseController(Updateable view) {
		this.view = view;
		universe = new Universe();
		maxRadius = universe.getCurrentRadius();
		Runnable r = new Runnable() {
			public void run() {
				doWork();
			}
		};
		innerThread = new Thread(r);
		innerThread.start();
	}
	
	public ArrayList<Body> getBodies() {
		return universe.getBodies();
	}
	
	public BigDecimal getMaxRadius() {
		return maxRadius;
	}

	public void moveInTime(double numberOfSteps) {
		for (int i=0; i<numberOfSteps; i++) {
			universe.moveUniverseInTime();
		}
		BigDecimal currentRadius = universe.getCurrentRadius();
		if (currentRadius.compareTo(maxRadius) == 1) {
			maxRadius = currentRadius;
		}
	}
	
	private void doWork() {
		while (true) {
			moveInTime(1);
			numberOfStepsTaken++;
			if ((numberOfStepsTaken % UPDATE_FREQUENCY) == 0) {
				view.update();
			}
		}
	}
	
	public long getElapsedTime() {
		return numberOfStepsTaken * INTERVAL;
	}

	@Override
	public String toString() {
		return "UniverseController [universe=" + universe
				+ ", numberOfStepsTaken=" + numberOfStepsTaken + "]";
	}

}
