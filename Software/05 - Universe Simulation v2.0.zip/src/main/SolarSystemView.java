package main;

import static util.Constants.BORDER_SIZE;
import static util.Constants.ROUND;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.math.BigDecimal;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import physics.Body;

public class SolarSystemView implements Updateable {

	private JFrame frame;
	private UniverseController controller;
	private int maxScreenSize;
	private JTextField elapsedTime = new JTextField("Put some very long text here. You know, as in lots of characters.");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SolarSystemView window = new SolarSystemView();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SolarSystemView() {
		controller = new UniverseController(this);
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private synchronized  void initialize() {
		frame = new JFrame();
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		double width = screenSize.getWidth();
		double height = screenSize.getHeight();
		maxScreenSize = (width < height) ? (int)width-BORDER_SIZE : (int)height-BORDER_SIZE;
		
		frame.setBounds(0, 0, (int) ((maxScreenSize+50)*1.5), maxScreenSize+50);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new BorderLayout());
		JPanel grapicsView = new SolarSystemPanel();
		frame.add(grapicsView, BorderLayout.CENTER);
		
		// Create planet table
		JTable speedList = new JTable(new PlanetTableModel(controller));
		JScrollPane planetScrollPane = new JScrollPane(speedList);
		JPanel statisticsPanel = new JPanel();
		statisticsPanel.setLayout(new BorderLayout());
		statisticsPanel.add(planetScrollPane, BorderLayout.CENTER);
		
		// Create timer
		JPanel timePanel = new JPanel();
		timePanel.add(elapsedTime);
		statisticsPanel.add(timePanel, BorderLayout.SOUTH);
		frame.add(statisticsPanel, BorderLayout.EAST);
		
		frame.setVisible(true);
	}
	
	@SuppressWarnings("serial")
	private class SolarSystemPanel extends JPanel {
		
		@Override
		public void paint(Graphics g) {
			ArrayList<Body> bodies = SolarSystemView.this.controller.getBodies();
			for (Body aBody: bodies) {
				int x = aBody.getLocation().getX().divide(getScreenScalingFactor(), ROUND).intValue();
				int y = aBody.getLocation().getY().divide(getScreenScalingFactor(), ROUND).intValue();
				drawBody(g, x,y,5, aBody.getName());
				int orbitSize = aBody.getLocation().getLength().divide(getScreenScalingFactor(), ROUND).intValue();
				drawOrbit(g, orbitSize);
			}
			
		}
		
		private BigDecimal getScreenScalingFactor() {
			return controller.getMaxRadius().divide(new BigDecimal(SolarSystemView.this.maxScreenSize),ROUND).multiply(new BigDecimal(2));
		}
		
		private void drawBody(Graphics g, int x, int y, int radius, String name) {
			g.fillOval(x+(maxScreenSize/2)-radius, y+(maxScreenSize/2)-radius, radius*2, radius*2);
			
			// Print the name of the body and it's relative coordinates
			String text = name + "(" + Integer.toString(x) + "," + Integer.valueOf(y) + ")";
			g.drawString(text, x+(maxScreenSize/2)-radius, y+(maxScreenSize/2)-radius);
		}
		
		private void drawOrbit(Graphics g, int radius) {
			g.drawOval((maxScreenSize/2)-radius, (maxScreenSize/2)-radius, radius*2, radius*2);
		}
	}

	@Override
	public synchronized void update() {
		long timer = controller.getElapsedTime();
		long years = timer / 31557600;
		long days = ((timer % 31557600) / 86400) % 365;
		long hours = ((timer - years * 31557600 - days - 86400) / 3600) % 24;
		elapsedTime.setText("Years: " + String.valueOf(years) + " Days: " + String.valueOf(days)+ " Hours: " + String.valueOf(hours));
		frame.repaint();
	}
}
