package physics;

import static util.Constants.EARTH_MASS;
import static util.Constants.EARTH_ORBIT;
import static util.Constants.EARTH_SPEED;
import static util.Constants.JUPITER_MASS;
import static util.Constants.JUPITER_ORBIT;
import static util.Constants.JUPITER_SPEED;
import static util.Constants.MARS_MASS;
import static util.Constants.MARS_ORBIT;
import static util.Constants.MARS_SPEED;
import static util.Constants.MERCURY_MASS;
import static util.Constants.MERCURY_ORBIT;
import static util.Constants.MERCURY_SPEED;
import static util.Constants.NEPTUNE_MASS;
import static util.Constants.NEPTUNE_ORBIT;
import static util.Constants.NEPTUNE_SPEED;
import static util.Constants.PLUTO_MASS;
import static util.Constants.PLUTO_ORBIT;
import static util.Constants.PLUTO_SPEED;
import static util.Constants.SATURN_MASS;
import static util.Constants.SATURN_ORBIT;
import static util.Constants.SATURN_SPEED;
import static util.Constants.SOL_MASS;
import static util.Constants.SOL_ORBIT;
import static util.Constants.SOL_SPEED;
import static util.Constants.URANUS_MASS;
import static util.Constants.URANUS_ORBIT;
import static util.Constants.URANUS_SPEED;
import static util.Constants.VENUS_MASS;
import static util.Constants.VENUS_ORBIT;
import static util.Constants.VENUS_SPEED;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CyclicBarrier;

import math.Vector2D;
import util.Command;

public class Universe {
	private ArrayList<Body> bodies = new ArrayList<Body>();
	private final BlockingQueue<Command> commandQueue;
	private final CyclicBarrier synchronizationBarrier;
	
	public Universe() {
		
		commandQueue = new ArrayBlockingQueue<>(8);
		synchronizationBarrier = new CyclicBarrier(8);
		buildUniverse2D();
	}
	
	public ArrayList<Body> getBodies() {
		return bodies;
	}
	
	public void moveUniverseInTime() {
		for (int i=0; i<bodies.size(); i++) {
			try {
				commandQueue.put(Command.MOVE);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public BigDecimal getCurrentRadius() {
		BigDecimal result = BigDecimal.ZERO;
		for (Body aBody: bodies) {
			BigDecimal length = aBody.getLocation().getLength();
			if (length.compareTo(result) == 1) {
				result = length;
			}
		}
		return result;
	}

	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		for (Body aBody: bodies) {
			result.append(aBody.toString());
			result.append(System.getProperty("line.separator"));
		}
		result.append(System.getProperty("line.separator"));
		for (Body aBody: bodies) {
			result.append("Total gravity felt by "+ aBody.getName() + ": " + aBody.getTotalGravitationalPull());
			result.append(System.getProperty("line.separator"));
		}
		return new String(result);
	}
	
	@SuppressWarnings("unused")
	private void buildUniverse2D() { 
		//sun at the centre
		Body sun = new Body("Sun",SOL_MASS,new Vector2D(SOL_ORBIT,BigDecimal.ZERO),new Vector2D(BigDecimal.ZERO,SOL_SPEED), this, synchronizationBarrier, commandQueue);
		//mercury 90 degrees
		Body mercury = new Body("Mercury",MERCURY_MASS,new Vector2D(BigDecimal.ZERO,MERCURY_ORBIT),new Vector2D(MERCURY_SPEED.negate(),BigDecimal.ZERO), this, synchronizationBarrier, commandQueue);
		//venus 180 degrees
		Body venus = new Body("Venus",VENUS_MASS,new Vector2D(VENUS_ORBIT.negate(),BigDecimal.ZERO),new Vector2D(BigDecimal.ZERO,VENUS_SPEED.negate()), this, synchronizationBarrier, commandQueue);
		//earth -90 degrees
		Body earth = new Body("Earth",EARTH_MASS,new Vector2D(BigDecimal.ZERO,EARTH_ORBIT.negate()),new Vector2D(EARTH_SPEED,BigDecimal.ZERO), this, synchronizationBarrier, commandQueue);
		//mars 0 degrees
		Body mars = new Body("Mars",MARS_MASS,new Vector2D(MARS_ORBIT,BigDecimal.ZERO),new Vector2D(BigDecimal.ZERO,MARS_SPEED), this, synchronizationBarrier, commandQueue);
		//jupiter 90 degrees
		Body jupiter = new Body("Jupiter",JUPITER_MASS,new Vector2D(BigDecimal.ZERO,JUPITER_ORBIT),new Vector2D(JUPITER_SPEED.negate(),BigDecimal.ZERO), this, synchronizationBarrier, commandQueue);
		//saturn 180 degrees
		Body saturn= new Body("Saturn",SATURN_MASS,new Vector2D(SATURN_ORBIT.negate(),BigDecimal.ZERO),new Vector2D(BigDecimal.ZERO,SATURN_SPEED.negate()), this, synchronizationBarrier, commandQueue);
		//uranus -90 degrees
		Body uranus = new Body("Uranus",URANUS_MASS,new Vector2D(BigDecimal.ZERO,URANUS_ORBIT.negate()),new Vector2D(URANUS_SPEED,BigDecimal.ZERO), this, synchronizationBarrier, commandQueue);
		//neptune 0 degrees
		Body neptune = new Body("Neptune",NEPTUNE_MASS,new Vector2D(NEPTUNE_ORBIT,BigDecimal.ZERO),new Vector2D(BigDecimal.ZERO,NEPTUNE_SPEED), this, synchronizationBarrier, commandQueue);
		//pluto 90 degrees
		Body pluto = new Body("Pluto",PLUTO_MASS,new Vector2D(BigDecimal.ZERO,PLUTO_ORBIT),new Vector2D(PLUTO_SPEED.negate(),BigDecimal.ZERO), this, synchronizationBarrier, commandQueue); 
		
		bodies.add(sun);
		bodies.add(mercury);
		bodies.add(venus);
		bodies.add(earth);
		bodies.add(mars);
		bodies.add(jupiter);
		bodies.add(saturn);
		bodies.add(uranus);
		bodies.add(neptune);
		bodies.add(pluto);
	}
}
