package physics;
import static util.Constants.DECIMALS;
import static util.Constants.G;
import static util.Constants.ROUND;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

import math.Vector2D;
import util.Command;

public class Body {
	private String name;
	private BigDecimal weight; // Weight in kg
	private volatile Vector2D location; // in m, m, m
	private Vector2D velocity; //in m, m, m
	private Thread innerThread;
	private CyclicBarrier synchronizationBarrier;
	private Universe universe;
	
	public Body(String name, BigDecimal weight, Vector2D location,  Vector2D velocity, Universe universe, CyclicBarrier synchronizationBarrier, final BlockingQueue<Command> commandQueue) {
		this.name = name;
		this.weight = weight;
		this.location = location;
		this.velocity = velocity;
		this.universe = universe;
		this.synchronizationBarrier = synchronizationBarrier;
		
		Runnable r = new Runnable() {
			public void run() {
				while (true) {
					try {
						Command command = commandQueue.take();
						if (command == Command.MOVE) doWork();
					} catch (InterruptedException | BrokenBarrierException e) {
						e.printStackTrace();
						System.exit(0);
					}
				}
			}
		};
		innerThread = new Thread(r);
		innerThread.start();
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public Vector2D getLocation(){
		return location;
	}
	
	public void setLocation(Vector2D location){
		this.location = location;
	}
	
	public Vector2D getVelocity() {
		return velocity;
	}

	public void setVelocity(Vector2D velocity) {
		this.velocity = velocity;
	}

	public void addWeight(BigDecimal weight) {
		this.weight = this.weight.add(weight);
	}
	
	public BigDecimal getDistance(Body other) {
		return location.getDistance(other.location);
	}
	
	public void move(Vector2D deltaVelocity){
		velocity = velocity.add(deltaVelocity);
		location = location.add(velocity);
	}
	
	// Critical code following
	
	public Vector2D getGravitationalPull(Body other) {
		Vector2D force = other.getLocation().minus(this.getLocation());
		BigDecimal r = force.getLength();
		BigDecimal m1 = other.getWeight();
		if(r.compareTo(new BigDecimal("1"))==1) {
			BigDecimal m1m2 = m1.divide(this.getWeight(), ROUND);
			BigDecimal g = G;
			BigDecimal r2 = r.multiply(r);
			BigDecimal value =  (g.multiply(m1m2)).divide(r2,DECIMALS,ROUND); 
			force = force.times(value.divide(r,DECIMALS,ROUND)); 
		}
		return force;
	}
	
	public Vector2D  getTotalGravitationalPull() {
		Vector2D totalForce = new Vector2D(BigDecimal.ZERO, BigDecimal.ZERO);
		Collection<Body> bodies = universe.getBodies();
		for (Body other: bodies) {
			totalForce = totalForce.add(this.getGravitationalPull(other));
		}
		return totalForce;
	}
	
	private void doWork() throws InterruptedException, BrokenBarrierException {
		Vector2D deltaVelocity = getTotalGravitationalPull();
		synchronizationBarrier.await();
		move(deltaVelocity);
	}
	
	public String toString(){
		return ""+ name +", location: "+ location.toString()+", speed: "+ velocity.toString();
	}
}
