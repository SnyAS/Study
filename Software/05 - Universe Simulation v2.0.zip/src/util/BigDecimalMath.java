package util;

import static util.Constants.DECIMALS;
import static util.Constants.ROUND;

import java.math.BigDecimal;

public class BigDecimalMath {
	
	public static BigDecimal sqrt(BigDecimal number){
		if(number.compareTo(BigDecimal.ZERO) < 0){
			throw new ArithmeticException("Taking root of negative number");
		} else if (number.compareTo(BigDecimal.ZERO) == 0){
			return BigDecimal.ZERO;
		} else {
			BigDecimal two = new BigDecimal("2");
			BigDecimal nr0 = two;
			BigDecimal nr1 = new BigDecimal("20");
			for (int i = 0; i < 10000; i++) {
				nr1 = (nr0.add(number.divide(nr0,DECIMALS,ROUND))).divide(two,DECIMALS,ROUND);
				if(nr1.compareTo(nr0) == 0){
					return nr1;
				} 
				nr0 = nr1;
			}
			return nr1;
		} 
	}
}
