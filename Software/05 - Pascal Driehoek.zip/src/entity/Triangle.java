package entity;

public class Triangle {
	private int[][] triangle; // First dimension is depth; second one is width, which is depended on the depth (ragged array)
	private int largestValue = 1;
	
	public Triangle(int size) {
		triangle = new int[size][];
		fillTriangle();
	}
	
	public void print() {
		String printFormat = "%" + ((int) Math.log10(largestValue)) + "d";
		for (int i=0; i<triangle.length; i++) {
			for (int j=0; j<triangle[i].length; j++) {
				System.out.printf(printFormat, triangle[i][j]);
				System.out.print(" ");
			}
			System.out.println(" ");
		}	
	}
	
	public void printStructure() {
		String printFormat = "%" + ((int) Math.log10(largestValue)) + "s";
		for (int i=0; i<triangle.length; i++) {
			for (int j=0; j<triangle[i].length; j++) {
				if (triangle[i][j]%2 == 1) {
					System.out.printf(printFormat, "*");
				}
				else {
					System.out.printf(printFormat, " ");
				}
				System.out.print(" ");
			}
			System.out.println(" ");
		}	
	}

	private void fillTriangle() {
		for (int i=0; i<triangle.length; i++) {
			triangle[i] = new int[i+1];
			triangle[i][0] = 1;
			for (int j=1; j<triangle[i].length-1; j++) {
				triangle[i][j] = triangle[i-1][j-1] + triangle[i-1][j];
				if (triangle[i][j] > largestValue) {
					largestValue = triangle[i][j];
				}
			}
			triangle[i][triangle[i].length-1]= 1;
		}
	}
	
	public static void main(String[] args) {
		Triangle testTriangle= new Triangle(20);
		testTriangle.printStructure();
	}
}
