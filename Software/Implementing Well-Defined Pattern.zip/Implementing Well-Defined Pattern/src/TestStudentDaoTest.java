

import static org.junit.Assert.fail;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class TestStudentDaoTest {
//tdd
	private IDAO studentDao = new StudentDao();

	@Before
	public void init() {
		studentDao.addStudent(new Student("Pijotr", 1));
		studentDao.addStudent(new Student("D", 2));
	}

	@Test
	public void testDeleteStudent() {

	}

	@Test
	public void testGetAllStudent() {
		List<Student> students = studentDao.getAllStudents();
		assertnotNull(students);
	}

	@Test
	public void testUpdateStudent() {
		studentDao.updateStudent(new Student("f", 1));
		if (!studentDao.getStudent(1).getName().equals("f")) {
			fail("change fail");
		}
	}

	@Test
	public void testAddStudent() {
		studentDao.addStudent(new Student("n", 0));
		if (!studentDao.getStudent(0).getName().equals("n")) {
			fail("wrong student");
		}
	}
}
