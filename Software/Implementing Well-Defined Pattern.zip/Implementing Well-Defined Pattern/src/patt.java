
public interface INetwork{
	URLConnection connect();
}

public interface INetworkFactory{
	final int NETWORK_EMPTY = 1;
	final int NETWORK_DIRTY = 2;
	final int NETWORK_REAL = 3;
	
	INetwork getNetwork(int type);
}

public class netFac  implements INetworkFactory{
//compound pattern
	
	@Override
	public INetwork getNetwork(int type){
		switch(type){
		case NETWORK_EMPTY: return new MockNetwork();
		case NETWORK_DIRTY: return new DirtyNetwork();
		case NETWORK_REAL : return new RealNetwork();
		case default: return null;
		}
	}
}

public class MockNetwork implements INetwork{
	@Override
	public URLConnection connect(){
		return null;
	}
}
