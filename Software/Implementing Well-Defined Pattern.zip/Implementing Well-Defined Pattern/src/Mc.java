

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

public class Mc {

	//initialize method to create obj you  need for testing
	private McDonalds restaurant;
		
	@Before
	public void initialize(){
		restaurant = new MacDonalds();
		for(int i =0; i< 30; i++){
			restaurant.addBurger(new Burger("Cheese", 4.99d));
		}
	}
//retrieve an iteration using method iteratior on the iterable moving through it has next & print
	
	
	@Test
	public void testNext() {
		IIterator i = restaurant.iterator();
		while(i.hasNext()){
			if(!i.next().getName().equals("Cheese")){
				fail("No Cheese");
			}
		}		
	}
	
	//retrieve a "burger" from iterator when @end of iteration fails with expectation defined in interface
	@Test(expected=NoSuchElementException.class)
	public void testNextIllegal(){
		IIterator i = restaurant.iterator();
		while (i.hasNext()){
			i.next();
		}
		i.next();
	}
}
