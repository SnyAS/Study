import java.util.LinkedList;

public class ShoppingCartHistory implements IMemento{
	
	//add & remove items moving back 1 step by rollback
	private LinkedList<ShoppingCart> history;
	private ShoppingCart cart;
	
	public ShoppingCartHistory(ShoppingCart cart) {
		this.cart = cart;
		history = new LinkedList<ShoppingCart>();
	}
	
	@Override
	public void store(){
		history.add(cart.clone());
	}
	
	@Override
	public ShoppingCart rollback(){
		return history.removeLast();
	}
}
