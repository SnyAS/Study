import java.util.EmptyStackException;

/**
 * @author Marik Boswijk
 */
public class Stack_Array<E> {
    private Object[] array;
    private int index;

    public Stack_Array() {
        this(16);
    }

    public Stack_Array(int initSize) {
        array = new Object[initSize];
        index = -1;
    }

    public int size() {
        return index + 1;
    }

    public boolean isEmpty() {
        return index == -1;
    }

    public void push(E value) {
        if (size() == array.length) {
            Object[] temp = new Object[array.length*2];
            for (int i = 0; i <= index; i++) {
                temp[i] = array[i];
            }
            array = temp;
        }
        array[++index] = value;
    }

    public E pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        E value = (E)array[index--];
        if (size() <= array.length / 2) {
            Object[] temp = new Object[(int)Math.floor(array.length/2)];
            for (int i = 0; i <= index; i++) {
                temp[i] = array[i];
            }
            array = temp;
        }
        return value;
    }
}
