import java.util.EmptyStackException;

/**
 * @author Marik Boswijk
 */
public class Stack_LinkedList<E> {
    private Node first = null;
	private int size = 0;

    public void push(E value) {
        first = new Node(value, first);
		size++;
    }

    public E pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        E value = first.value;
        first = first.next;
		size--;
        return value;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return first == null;
    }

    private class Node {
        private E value;
        private Node next;

        private Node(E value, Node next) {
            this.value = value;
            this.next = next;
        }
    }
}
