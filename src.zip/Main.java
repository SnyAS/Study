/**
 * @author Marik Boswijk
 */
public class Main {
    public static void main(String[] args) {
        Stack_Array<Integer> stackArr = new Stack_Array<>();
        Stack_LinkedList<Integer> stackLiLi = new Stack_LinkedList<>();

        for (int i = 0; i < 50; i++) {
            stackArr.push(i);
        }
        if (stackArr.pop() == 49) {
            System.out.println("Success!");
        }

        for (int i = 0; i < 30; i++) {
            stackArr.pop();
        }

        for (int i = 0; i < 50; i++) {
            stackLiLi.push(i);
        }
        if (stackLiLi.pop() == 49 && stackLiLi.pop() == 48 && stackLiLi.pop() == 47 && stackLiLi.pop() == 46
                && stackLiLi.pop() == 45 && stackLiLi.pop() == 44 && stackLiLi.pop() == 43) {
            System.out.println("Success!");
        }
    }
}
