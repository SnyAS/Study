import java.util.ArrayList;

class Question3 {

    static Object seeTopOfStack(GenericStack genericStack) {
        Object returnValue = null;
        if(!genericStack.isEmpty()){
            returnValue = genericStack.pop();
            genericStack.push(returnValue);
        }
        return returnValue;
    }

    static GenericStack removeTopOfStack(GenericStack genericStack) {
        if(!genericStack.isEmpty()){
            genericStack.pop();
        }
        return genericStack;
    }

    static Object seeBottomOfStack(GenericStack genericStack) {
        return seeElementAt(genericStack, genericStack.size()+1);

    }

    static GenericStack removeBottomOfStack(GenericStack genericStack) {
        return removeElementAt(genericStack, genericStack.size()+1);

    }

    static Object seeElementAt(GenericStack genericStack, int location) {

        int size = genericStack.size();
        Object[] holdList = new Object[size];
        int i;
        for (i = 0; i < location-1; i++) {
            holdList[i] = genericStack.pop();
        }
        i--;
        Object returnValue = holdList[i];
        for (; i >= 0; i--) {
            genericStack.push(holdList[i]);
        }
        return returnValue;
    }

    static GenericStack removeElementAt(GenericStack genericStack, int location) {

        int size = genericStack.size();
        Object[] holdList = new Object[size];
        int i;
        for (i = 0; i < location-1; i++) {
            holdList[i] = genericStack.pop();
        }
        i--;
        i--;
        for (; i >= 0; i--) {
            genericStack.push(holdList[i]);
        }
        return genericStack;
    }
}
