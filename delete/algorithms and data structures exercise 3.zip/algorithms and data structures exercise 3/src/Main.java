public class Main {

    public static void main(String[] args) {
        //Question2.execute();

        GenericStack_array<String> genericStackArrString = new GenericStack_array<>(String.class, 2);

        genericStackArrString.push("im on the bottom, i will show once then be removed");
        genericStackArrString.push("im second from bottom  i will never show and not be removed");
        genericStackArrString.push("im in the middle and will show in the showAt, then be removed");
        genericStackArrString.push("im on top i will show once and then be removed");

        System.out.println(Question3.seeTopOfStack(genericStackArrString));
        Question3.removeTopOfStack(genericStackArrString);
        System.out.println(Question3.seeBottomOfStack(genericStackArrString));
        Question3.removeBottomOfStack(genericStackArrString);
        System.out.println(Question3.seeElementAt(genericStackArrString, 2));
        Question3.removeElementAt(genericStackArrString, 2);

        genericStackArrString.push("And this is whats left:");
        while(!genericStackArrString.isEmpty()){
            System.out.println(genericStackArrString.pop());

        }

    }
}
