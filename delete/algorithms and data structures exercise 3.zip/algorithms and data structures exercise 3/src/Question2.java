
class Question2 {
    static void execute() {
        GenericStack_array<String> genericStackArrString = new GenericStack_array<>(String.class, 2);


        genericStackArrString.push("TEST");
        genericStackArrString.push("resize");
        genericStackArrString.push("resize1");
        genericStackArrString.push("resize2");
        genericStackArrString.push("resize3");
        genericStackArrString.push("resize4");
        genericStackArrString.push("resize5");
        genericStackArrString.push("resize6");
        genericStackArrString.push("resize7");
        genericStackArrString.push("resize7");

        System.out.println(genericStackArrString.pop());
        System.out.println(genericStackArrString.pop());
        System.out.println(genericStackArrString.pop());
        System.out.println(genericStackArrString.pop());
        System.out.println(genericStackArrString.pop());
        System.out.println(genericStackArrString.pop());
        System.out.println(genericStackArrString.pop());
        System.out.println(genericStackArrString.pop());
        System.out.println(genericStackArrString.pop());
        GenericStack_array<Object> genericStackArrObj = new GenericStack_array<>(Object.class, 2);
        genericStackArrObj.push("resize");
        genericStackArrObj.push("resize1");
        genericStackArrObj.push(3);
        genericStackArrObj.push(1.1);


        GenericStack_array<Integer> genericStackArrInt = new GenericStack_array<>(Integer.class, 2);

        genericStackArrInt.push(2);
        genericStackArrInt.push(3);
        genericStackArrInt.push(4);
        genericStackArrInt.push(5);
        genericStackArrInt.push(6);
        System.out.println(genericStackArrInt.pop());
        System.out.println(genericStackArrInt.pop());
        System.out.println(genericStackArrInt.pop());
        System.out.println(genericStackArrInt.pop());

        GenericStack_linkedList<String> genericStack_linkedList = new GenericStack_linkedList<>();
        GenericStack_linkedList<Integer> genericStack_linkedListInt = new GenericStack_linkedList<>();
        genericStack_linkedList.push("TEST");
        genericStack_linkedList.push("resize");
        genericStack_linkedListInt.push(1);
        genericStack_linkedList.pop();
        System.out.println("Done!");

        GenericStack_linkedList<Object> genericStack_linkedListObj = new GenericStack_linkedList<>();
        genericStack_linkedListObj.push("resize");
        genericStack_linkedListObj.push("resize1");
        genericStack_linkedListObj.push(3);
        genericStack_linkedListObj.push(1.1);

    }
}
