
interface GenericStack<E> {
    void push(E input);

    E pop() ;

    int size();

    boolean isEmpty();

}
