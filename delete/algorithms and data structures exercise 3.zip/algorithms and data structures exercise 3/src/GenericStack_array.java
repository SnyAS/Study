import java.lang.reflect.Array;
import java.util.EmptyStackException;

class GenericStack_array<E> implements GenericStack<E>{

    private E[] stack;
    private int location;

    GenericStack_array(Class<E> c, int initialSize) {
        @SuppressWarnings("unchecked")
        final E[] stack = (E[]) Array.newInstance(c, initialSize);
        this.stack = stack;
        this.location = -1;
    }

    GenericStack_array(Class<E> c) {
        @SuppressWarnings("unchecked")
        final E[] stack = (E[]) Array.newInstance(c, 1);
        this.stack = stack;
        this.location = -1;
    }

    public void push(E input) {
        int length = this.stack.length;
        this.location++;
        if (this.location >= length) {
            Class e = this.stack.getClass().getComponentType();
            @SuppressWarnings("unchecked")
            E[] newStack = (E[]) Array.newInstance(e, length * 2);
            System.arraycopy(this.stack, 0, newStack, 0, length);
            this.stack = newStack;
        }
        this.stack[this.location] = input;

    }

    public E pop() {
        if (this.location < 0) {
            throw new EmptyStackException();
        }
        E returnValue = this.stack[this.location];

        if (this.location <= this.stack.length / 4) {
            int length = this.stack.length;
            Class e = this.stack.getClass().getComponentType();
            @SuppressWarnings("unchecked")
            E[] newStack = (E[]) Array.newInstance(e, length / 2);
            System.arraycopy(this.stack, 0, newStack, 0, length/2);
            this.stack = newStack;
        }
        this.location--;
        return returnValue;
    }

    public int size() {

        return this.location + 1;
    }

    public boolean isEmpty() {
        return this.location < 0;
    }


}
