import java.lang.reflect.Array;
import java.util.LinkedList;

class GenericStack_linkedList<E> {



    private LinkedList<E> stack;


    GenericStack_linkedList() {

        this.stack = new LinkedList<>();
    }


    void push(E input) {
        this.stack.push(input);
    }

    E pop() {
        return this.stack.pop();
    }

    int size() {

        return this.stack.size();
    }

    boolean isEmpty() {
        return this.stack.isEmpty();
    }


}
